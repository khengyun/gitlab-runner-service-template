# gitlab-runner-service

## This is template for gitlab runner service

 ```bash
docker exec -it gitlab-runner gitlab-runner register
docker exec -it gitlab-runner gitlab-runner start
docker exec -it gitlab-runner gitlab-runner restart
```
